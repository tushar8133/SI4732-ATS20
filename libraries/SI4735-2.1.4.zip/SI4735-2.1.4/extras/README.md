# Extras

In this folder you can see schematics, photos and extra files to help you to develop your project.
See images folder. See images folder.





